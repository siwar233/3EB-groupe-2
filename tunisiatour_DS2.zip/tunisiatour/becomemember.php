<?php
$a=$_POST['T1'];
$b=$_POST['T2'];
$c=$_POST['T3'];
$d=$_POST['T4'];
$e=$_POST['T5'];
$f=$_POST['T6'];
$g=$_POST['T8'];
$h=$_POST['T7'];
$i=$_POST['gender'];
$j=$_POST['Adults'];
$k=$_POST['Kids'];
$l=$_POST['ref'];


require('config.php');
$re = "INSERT INTO becomemember(Fname,Lname,Email,Vemail,Uname,Pass,country,Pnum,gender,Adults,Kids,Ref
)

VALUES('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k','$l')";

$ret = mysqli_query($conn,$re);
if($ret){
    echo"<div>
    <h3>Welcome!</h3>
    </div>";
}else echo'Somthing is wrong';
?>

