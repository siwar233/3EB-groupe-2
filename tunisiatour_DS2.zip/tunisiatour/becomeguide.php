<?php
$n=$_POST['lvl'];
$o=$_POST['fn'];
$p=$_POST['ml'];
$q=$_POST['bu'];
require('config.php');
$req = "INSERT INTO becomeguide(level,Name,mail,aboutyou)
VALUES('$n','$o','$p','$q')";

$res = mysqli_query($conn,$req);
if($res){
    echo"<div>
    <h3>You are a guide now!</h3>
    </div>";
}else echo'Somthing is wrong';
?>