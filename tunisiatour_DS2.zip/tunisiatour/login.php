<?php
$u=$_POST['Us'];
$p=$_POST['Ps'];
require('config.php');
session_start();
 
		

		if(!empty($u) && !empty($p) )
		{
            $_SESSION['$Us'] = $u;

			//read from database
			$query = "select * from login1 where Username = '$u' limit 1";
			$result = mysqli_query($conn, $query);

			
				if(mysqli_num_rows($result) == 1)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['type'] == 'Admin' )
					{

						header("Location: Admin.html");
                        
					
					}else {
                        header("Location: User.html");
                        
                    }
				}
			
			
	
		}else
		{
			echo "<script> alert (' wrong password ou username!')</script>";
		}
	
?>