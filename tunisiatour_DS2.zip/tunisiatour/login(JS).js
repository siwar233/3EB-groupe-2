function verif1()
{
    U = F1.Us.value;
    P = F1.Ps.value;
   if(U=="")
    {
        alert('Please enter your username!');
        return false;
    }
    if(P=="") 
    {
        alert('Please enter your username!');
        return false;
    }

}

