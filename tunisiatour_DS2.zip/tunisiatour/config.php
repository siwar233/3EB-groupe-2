<?php
define('serveur','localhost');
define('utilisateur','root');
define('motdepasse','');
define('base','bd1');

 $conn = mysqli_connect(serveur,utilisateur,motdepasse,base);

 if($conn === false){
    die("ERREUR : Impossible de se connecter." .mysqli_connect());
 }
 ?>